import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  FiSearch, 
  FiFilter, 
  FiCalendar, 
  FiDollarSign, 
  FiTrendingUp,
  FiArrowRight,
  FiStar,
  FiEye
} from 'react-icons/fi';
import { useQuery } from 'react-query';
import { format } from 'date-fns';
import './UpcomingIPOs.css';

// Mock data - replace with API calls
const mockIPOs = [
  {
    id: 1,
    companyName: 'TechCorp Solutions Ltd',
    symbol: 'TECHCORP',
    sector: 'Technology',
    issueSize: 500,
    priceBand: { min: 200, max: 220 },
    openDate: '2024-12-15',
    closeDate: '2024-12-18',
    lotSize: 68,
    status: 'upcoming',
    rating: 4.5,
    description: 'Leading technology solutions provider specializing in cloud computing and AI.',
    highlights: ['Strong financials', 'Growing market', 'Experienced management'],
    bookBuilding: true,
    gmp: 25
  },
  {
    id: 2,
    companyName: 'Green Energy Power Ltd',
    symbol: 'GREENPWR',
    sector: 'Energy',
    issueSize: 750,
    priceBand: { min: 150, max: 165 },
    openDate: '2024-12-20',
    closeDate: '2024-12-22',
    lotSize: 90,
    status: 'upcoming',
    rating: 4.2,
    description: 'Renewable energy company focused on solar and wind power generation.',
    highlights: ['Government support', 'Sustainable growth', 'High demand'],
    bookBuilding: true,
    gmp: 15
  },
  {
    id: 3,
    companyName: 'HealthCare Plus Ltd',
    symbol: 'HEALTHPLUS',
    sector: 'Healthcare',
    issueSize: 300,
    priceBand: { min: 180, max: 195 },
    openDate: '2024-12-25',
    closeDate: '2024-12-27',
    lotSize: 76,
    status: 'upcoming',
    rating: 4.7,
    description: 'Healthcare technology company providing innovative medical solutions.',
    highlights: ['Innovation leader', 'Strong patents', 'Global presence'],
    bookBuilding: false,
    gmp: 35
  },
  {
    id: 4,
    companyName: 'Finance First Ltd',
    symbol: 'FINANCE1ST',
    sector: 'Finance',
    issueSize: 1000,
    priceBand: { min: 250, max: 275 },
    openDate: '2024-12-30',
    closeDate: '2025-01-02',
    lotSize: 36,
    status: 'upcoming',
    rating: 4.3,
    description: 'Digital banking and financial services platform.',
    highlights: ['Digital transformation', 'Strong customer base', 'Regulatory compliance'],
    bookBuilding: true,
    gmp: 20
  },
  {
    id: 5,
    companyName: 'Retail Mart Ltd',
    symbol: 'RETAILMART',
    sector: 'Retail',
    issueSize: 400,
    priceBand: { min: 120, max: 135 },
    openDate: '2025-01-05',
    closeDate: '2025-01-08',
    lotSize: 111,
    status: 'upcoming',
    rating: 4.0,
    description: 'Modern retail chain with focus on consumer electronics and lifestyle products.',
    highlights: ['Omnichannel presence', 'Brand recognition', 'Operational efficiency'],
    bookBuilding: false,
    gmp: 10
  }
];

const UpcomingIPOs = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState('all');
  const [sortBy, setSortBy] = useState('date');
  const [viewMode, setViewMode] = useState('grid');

  // Mock API call using React Query
  const { data: ipos, isLoading, error } = useQuery('upcomingIPOs', () => {
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockIPOs), 1000);
    });
  });

  const sectors = ['all', 'Technology', 'Energy', 'Healthcare', 'Finance', 'Retail'];

  const filteredIPOs = ipos?.filter(ipo => {
    const matchesSearch = ipo.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ipo.symbol.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSector = selectedSector === 'all' || ipo.sector === selectedSector;
    return matchesSearch && matchesSector;
  }) || [];

  const sortedIPOs = [...filteredIPOs].sort((a, b) => {
    switch (sortBy) {
      case 'date':
        return new Date(a.openDate) - new Date(b.openDate);
      case 'size':
        return b.issueSize - a.issueSize;
      case 'rating':
        return b.rating - a.rating;
      case 'gmp':
        return b.gmp - a.gmp;
      default:
        return 0;
    }
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'upcoming': return '#10b981';
      case 'open': return '#f59e0b';
      case 'closed': return '#ef4444';
      default: return '#6b7280';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'upcoming': return 'Upcoming';
      case 'open': return 'Open';
      case 'closed': return 'Closed';
      default: return status;
    }
  };

  if (isLoading) {
    return (
      <div className="loading-container">
        <div className="loading"></div>
        <p>Loading upcoming IPOs...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <p>Error loading IPOs. Please try again later.</p>
      </div>
    );
  }

  return (
    <div className="upcoming-ipos">
      <div className="container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="page-header"
        >
          <div>
            <h1>Upcoming IPOs</h1>
            <p>Discover and analyze the latest Initial Public Offerings in the market</p>
          </div>
          <div className="view-toggle">
            <button
              className={`view-btn ${viewMode === 'grid' ? 'active' : ''}`}
              onClick={() => setViewMode('grid')}
            >
              Grid
            </button>
            <button
              className={`view-btn ${viewMode === 'list' ? 'active' : ''}`}
              onClick={() => setViewMode('list')}
            >
              List
            </button>
          </div>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="filters-section"
        >
          <div className="search-box">
            <FiSearch />
            <input
              type="text"
              placeholder="Search IPOs by company name or symbol..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="filter-controls">
            <div className="filter-group">
              <label>Sector:</label>
              <select
                value={selectedSector}
                onChange={(e) => setSelectedSector(e.target.value)}
              >
                {sectors.map(sector => (
                  <option key={sector} value={sector}>
                    {sector === 'all' ? 'All Sectors' : sector}
                  </option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label>Sort by:</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option value="date">Open Date</option>
                <option value="size">Issue Size</option>
                <option value="rating">Rating</option>
                <option value="gmp">GMP</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Results Count */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="results-count"
        >
          <p>{sortedIPOs.length} IPO{sortedIPOs.length !== 1 ? 's' : ''} found</p>
        </motion.div>

        {/* IPO Cards */}
        <div className={`ipos-container ${viewMode}`}>
          {sortedIPOs.map((ipo, index) => (
            <motion.div
              key={ipo.id}
              className="ipo-card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
            >
              <div className="ipo-header">
                <div className="ipo-title">
                  <h3>{ipo.companyName}</h3>
                  <span className="ipo-symbol">{ipo.symbol}</span>
                </div>
                <div className="ipo-rating">
                  <FiStar />
                  <span>{ipo.rating}</span>
                </div>
              </div>

              <div className="ipo-status">
                <span 
                  className="status-badge"
                  style={{ backgroundColor: getStatusColor(ipo.status) }}
                >
                  {getStatusText(ipo.status)}
                </span>
                {ipo.bookBuilding && (
                  <span className="book-building-badge">Book Building</span>
                )}
              </div>

              <div className="ipo-details">
                <div className="detail-row">
                  <span className="label">Sector:</span>
                  <span className="value">{ipo.sector}</span>
                </div>
                <div className="detail-row">
                  <span className="label">Issue Size:</span>
                  <span className="value">₹{ipo.issueSize} Cr</span>
                </div>
                <div className="detail-row">
                  <span className="label">Price Band:</span>
                  <span className="value">₹{ipo.priceBand.min} - ₹{ipo.priceBand.max}</span>
                </div>
                <div className="detail-row">
                  <span className="label">Lot Size:</span>
                  <span className="value">{ipo.lotSize} shares</span>
                </div>
                <div className="detail-row">
                  <span className="label">Open Date:</span>
                  <span className="value">{format(new Date(ipo.openDate), 'MMM dd, yyyy')}</span>
                </div>
                {ipo.gmp > 0 && (
                  <div className="detail-row gmp">
                    <span className="label">GMP:</span>
                    <span className="value positive">+₹{ipo.gmp}</span>
                  </div>
                )}
              </div>

              <div className="ipo-highlights">
                <h4>Key Highlights:</h4>
                <ul>
                  {ipo.highlights.map((highlight, idx) => (
                    <li key={idx}>{highlight}</li>
                  ))}
                </ul>
              </div>

              <div className="ipo-actions">
                <Link to={`/ipo/${ipo.id}`} className="btn btn-primary">
                  <FiEye />
                  View Details
                </Link>
                <button className="btn btn-secondary">
                  <FiTrendingUp />
                  Track
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Empty State */}
        {sortedIPOs.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="empty-state"
          >
            <div className="empty-icon">📊</div>
            <h3>No IPOs Found</h3>
            <p>Try adjusting your search criteria or filters to find more IPOs.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default UpcomingIPOs; 