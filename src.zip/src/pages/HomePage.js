import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  FiTrendingUp, 
  FiBarChart, 
  FiShield, 
  FiZap, 
  FiUsers, 
  FiDollarSign,
  FiArrowRight,
  FiCheckCircle
} from 'react-icons/fi';
import './HomePage.css';

const HomePage = () => {
  const features = [
    {
      icon: <FiTrendingUp />,
      title: 'Real-time IPO Tracking',
      description: 'Stay updated with the latest IPO announcements, dates, and market trends in real-time.'
    },
    {
      icon: <FiBarChart />,
      title: 'Advanced Analytics',
      description: 'Comprehensive analysis tools to evaluate IPO performance and make informed investment decisions.'
    },
    {
      icon: <FiShield />,
      title: 'Secure Platform',
      description: 'Bank-grade security to protect your data and ensure safe investment transactions.'
    },
    {
      icon: <FiZap />,
      title: 'Instant Notifications',
      description: 'Get instant alerts for new IPOs, price changes, and important market updates.'
    },
    {
      icon: <FiUsers />,
      title: 'Expert Insights',
      description: 'Access to expert analysis and recommendations from seasoned market professionals.'
    },
    {
      icon: <FiDollarSign />,
      title: 'Portfolio Management',
      description: 'Track your IPO investments and manage your portfolio with advanced tools.'
    }
  ];

  const stats = [
    { number: '500+', label: 'IPOs Tracked' },
    { number: '50K+', label: 'Active Users' },
    { number: '₹1000Cr+', label: 'Investment Volume' },
    { number: '95%', label: 'Success Rate' }
  ];

  const benefits = [
    'Comprehensive IPO database with real-time updates',
    'Advanced filtering and search capabilities',
    'Detailed company financials and prospectus analysis',
    'Market sentiment and social media monitoring',
    'Mobile-responsive design for on-the-go access',
    'Integration with major trading platforms'
  ];

  return (
    <div className="homepage">
      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="hero-content"
          >
            <h1>
              Your Gateway to 
              <span className="highlight"> IPO Success</span>
            </h1>
            <p>
              Discover, analyze, and invest in the most promising Initial Public Offerings. 
              Get comprehensive insights, real-time data, and expert analysis to make informed investment decisions.
            </p>
            <div className="hero-buttons">
              <Link to="/upcoming-ipos" className="btn btn-primary">
                Explore IPOs
                <FiArrowRight />
              </Link>
              <Link to="/register" className="btn btn-secondary">
                Get Started Free
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="section-title">Why Choose Bluestock Fintech?</h2>
            <p className="section-subtitle">
              We provide the most comprehensive IPO platform with cutting-edge features 
              designed to help you succeed in the IPO market.
            </p>
          </motion.div>
          
          <div className="grid grid-3">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="feature-card"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="feature-icon">
                  {feature.icon}
                </div>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="section-title">Trusted by Thousands</h2>
          </motion.div>
          
          <div className="stats-grid">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="stat-item"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="stat-number">{stat.number}</div>
                <div className="stat-label">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="section">
        <div className="container">
          <div className="benefits-content">
            <motion.div
              className="benefits-text"
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="section-title">Everything You Need for IPO Success</h2>
              <p className="section-subtitle">
                Our platform provides all the tools and insights you need to make 
                informed decisions in the IPO market.
              </p>
              <ul className="benefits-list">
                {benefits.map((benefit, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <FiCheckCircle />
                    {benefit}
                  </motion.li>
                ))}
              </ul>
              <Link to="/upcoming-ipos" className="btn btn-primary">
                Start Exploring
                <FiArrowRight />
              </Link>
            </motion.div>
            
            <motion.div
              className="benefits-visual"
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="mockup-card">
                <div className="mockup-header">
                  <div className="mockup-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <div className="mockup-content">
                  <div className="mockup-chart"></div>
                  <div className="mockup-data">
                    <div className="data-row">
                      <span>Company</span>
                      <span>TechCorp Ltd</span>
                    </div>
                    <div className="data-row">
                      <span>Issue Size</span>
                      <span>₹500 Cr</span>
                    </div>
                    <div className="data-row">
                      <span>Price Band</span>
                      <span>₹200-220</span>
                    </div>
                    <div className="data-row">
                      <span>Open Date</span>
                      <span>15 Dec 2024</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <motion.div
            className="cta-content"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2>Ready to Start Your IPO Journey?</h2>
            <p>
              Join thousands of investors who trust Bluestock Fintech for their IPO investments. 
              Get started today and never miss another great opportunity.
            </p>
            <div className="cta-buttons">
              <Link to="/register" className="btn btn-primary">
                Create Free Account
              </Link>
              <Link to="/upcoming-ipos" className="btn btn-secondary">
                Browse IPOs
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage; 