import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  FiTrendingUp, 
  FiTrendingDown, 
  FiDollarSign, 
  FiBarChart,
  FiEye,
  FiStar,
  FiCalendar,
  FiArrowUp,
  FiArrowDown
} from 'react-icons/fi';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import './Dashboard.css';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');

  // Mock data - replace with API calls
  const portfolioValue = 125000;
  const totalReturn = 15.5;
  const isPositive = totalReturn >= 0;

  const recentIPOs = [
    {
      id: 1,
      company: 'TechCorp Solutions',
      symbol: 'TECHCORP',
      invested: 50000,
      currentValue: 57500,
      return: 15.0,
      status: 'active'
    },
    {
      id: 2,
      company: 'Green Energy Power',
      symbol: 'GREENPWR',
      invested: 30000,
      currentValue: 28500,
      return: -5.0,
      status: 'active'
    },
    {
      id: 3,
      company: 'HealthCare Plus',
      symbol: 'HEALTHPLUS',
      invested: 25000,
      currentValue: 31250,
      return: 25.0,
      status: 'active'
    }
  ];

  const upcomingIPOs = [
    {
      id: 4,
      company: 'Finance First Ltd',
      symbol: 'FINANCE1ST',
      openDate: '2024-12-30',
      issueSize: 1000,
      priceBand: '₹250-275'
    },
    {
      id: 5,
      company: 'Retail Mart Ltd',
      symbol: 'RETAILMART',
      openDate: '2025-01-05',
      issueSize: 400,
      priceBand: '₹120-135'
    }
  ];

  // Chart data
  const portfolioChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Portfolio Value',
        data: [100000, 105000, 98000, 110000, 115000, 108000, 120000, 118000, 125000, 122000, 128000, 125000],
        borderColor: '#667eea',
        backgroundColor: 'rgba(102, 126, 234, 0.1)',
        fill: true,
        tension: 0.4,
      },
    ],
  };

  const sectorChartData = {
    labels: ['Technology', 'Healthcare', 'Energy', 'Finance', 'Retail'],
    datasets: [
      {
        data: [40, 25, 20, 10, 5],
        backgroundColor: [
          '#667eea',
          '#10b981',
          '#f59e0b',
          '#ef4444',
          '#8b5cf6',
        ],
        borderWidth: 0,
      },
    ],
  };

  const performanceChartData = {
    labels: ['TechCorp', 'GreenPWR', 'HealthPlus'],
    datasets: [
      {
        label: 'Return %',
        data: [15.0, -5.0, 25.0],
        backgroundColor: ['#10b981', '#ef4444', '#10b981'],
        borderWidth: 0,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: '#f1f5f9',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          usePointStyle: true,
          padding: 20,
        },
      },
    },
  };

  return (
    <div className="dashboard">
      <div className="container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="dashboard-header"
        >
          <div>
            <h1>Dashboard</h1>
            <p>Welcome back! Here's your IPO investment overview</p>
          </div>
          <div className="date-info">
            <FiCalendar />
            <span>{new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}</span>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="stats-grid"
        >
          <div className="stat-card">
            <div className="stat-icon portfolio">
              <FiDollarSign />
            </div>
            <div className="stat-content">
              <h3>Portfolio Value</h3>
              <p className="stat-value">₹{portfolioValue.toLocaleString()}</p>
              <div className={`stat-change ${isPositive ? 'positive' : 'negative'}`}>
                {isPositive ? <FiArrowUp /> : <FiArrowDown />}
                {Math.abs(totalReturn)}%
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon investments">
                              <FiBarChart />
            </div>
            <div className="stat-content">
              <h3>Total Investments</h3>
              <p className="stat-value">₹{recentIPOs.reduce((sum, ipo) => sum + ipo.invested, 0).toLocaleString()}</p>
              <div className="stat-change positive">
                <FiArrowUp />
                3 IPOs
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon returns">
              <FiTrendingUp />
            </div>
            <div className="stat-content">
              <h3>Total Returns</h3>
              <p className="stat-value">₹{recentIPOs.reduce((sum, ipo) => sum + (ipo.currentValue - ipo.invested), 0).toLocaleString()}</p>
              <div className={`stat-change ${isPositive ? 'positive' : 'negative'}`}>
                {isPositive ? <FiArrowUp /> : <FiArrowDown />}
                {totalReturn}%
              </div>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon watchlist">
              <FiStar />
            </div>
            <div className="stat-content">
              <h3>Watchlist</h3>
              <p className="stat-value">{upcomingIPOs.length}</p>
              <div className="stat-change positive">
                <FiArrowUp />
                Upcoming IPOs
              </div>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="dashboard-tabs"
        >
          <button
            className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </button>
          <button
            className={`tab-btn ${activeTab === 'portfolio' ? 'active' : ''}`}
            onClick={() => setActiveTab('portfolio')}
          >
            Portfolio
          </button>
          <button
            className={`tab-btn ${activeTab === 'watchlist' ? 'active' : ''}`}
            onClick={() => setActiveTab('watchlist')}
          >
            Watchlist
          </button>
        </motion.div>

        {/* Tab Content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="tab-content"
        >
          {activeTab === 'overview' && (
            <div className="overview-content">
              <div className="chart-grid">
                <div className="chart-card">
                  <h3>Portfolio Performance</h3>
                  <div className="chart-container">
                    <Line data={portfolioChartData} options={chartOptions} />
                  </div>
                </div>

                <div className="chart-card">
                  <h3>Sector Allocation</h3>
                  <div className="chart-container">
                    <Doughnut data={sectorChartData} options={doughnutOptions} />
                  </div>
                </div>
              </div>

              <div className="recent-ipos">
                <h3>Recent IPO Investments</h3>
                <div className="ipo-list">
                  {recentIPOs.map((ipo) => (
                    <div key={ipo.id} className="ipo-item">
                      <div className="ipo-info">
                        <h4>{ipo.company}</h4>
                        <span className="ipo-symbol">{ipo.symbol}</span>
                      </div>
                      <div className="ipo-values">
                        <div className="value-group">
                          <span className="label">Invested</span>
                          <span className="value">₹{ipo.invested.toLocaleString()}</span>
                        </div>
                        <div className="value-group">
                          <span className="label">Current</span>
                          <span className="value">₹{ipo.currentValue.toLocaleString()}</span>
                        </div>
                        <div className="value-group">
                          <span className="label">Return</span>
                          <span className={`value ${ipo.return >= 0 ? 'positive' : 'negative'}`}>
                            {ipo.return >= 0 ? '+' : ''}{ipo.return}%
                          </span>
                        </div>
                      </div>
                      <button className="btn btn-secondary">
                        <FiEye />
                        View
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'portfolio' && (
            <div className="portfolio-content">
              <div className="portfolio-header">
                <h3>Portfolio Performance</h3>
                <div className="chart-container large">
                  <Bar data={performanceChartData} options={chartOptions} />
                </div>
              </div>

              <div className="portfolio-details">
                <h3>Investment Details</h3>
                <div className="details-grid">
                  {recentIPOs.map((ipo) => (
                    <div key={ipo.id} className="detail-card">
                      <div className="detail-header">
                        <h4>{ipo.company}</h4>
                        <span className={`status ${ipo.status}`}>{ipo.status}</span>
                      </div>
                      <div className="detail-body">
                        <div className="detail-row">
                          <span>Symbol:</span>
                          <span>{ipo.symbol}</span>
                        </div>
                        <div className="detail-row">
                          <span>Invested Amount:</span>
                          <span>₹{ipo.invested.toLocaleString()}</span>
                        </div>
                        <div className="detail-row">
                          <span>Current Value:</span>
                          <span>₹{ipo.currentValue.toLocaleString()}</span>
                        </div>
                        <div className="detail-row">
                          <span>Return:</span>
                          <span className={ipo.return >= 0 ? 'positive' : 'negative'}>
                            {ipo.return >= 0 ? '+' : ''}{ipo.return}%
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'watchlist' && (
            <div className="watchlist-content">
              <h3>Upcoming IPOs</h3>
              <div className="watchlist-grid">
                {upcomingIPOs.map((ipo) => (
                  <div key={ipo.id} className="watchlist-card">
                    <div className="watchlist-header">
                      <h4>{ipo.company}</h4>
                      <span className="symbol">{ipo.symbol}</span>
                    </div>
                    <div className="watchlist-details">
                      <div className="detail-item">
                        <span className="label">Open Date:</span>
                        <span className="value">{new Date(ipo.openDate).toLocaleDateString()}</span>
                      </div>
                      <div className="detail-item">
                        <span className="label">Issue Size:</span>
                        <span className="value">₹{ipo.issueSize} Cr</span>
                      </div>
                      <div className="detail-item">
                        <span className="label">Price Band:</span>
                        <span className="value">{ipo.priceBand}</span>
                      </div>
                    </div>
                    <div className="watchlist-actions">
                      <button className="btn btn-primary">
                        <FiEye />
                        View Details
                      </button>
                      <button className="btn btn-secondary">
                        <FiStar />
                        Track
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard; 