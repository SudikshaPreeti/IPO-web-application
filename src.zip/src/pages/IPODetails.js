import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  FiArrowLeft, 
  FiTrendingUp, 
  FiTrendingDown, 
  FiDollarSign, 
  FiCalendar,
  FiBarChart3,
  FiStar,
  FiEye,
  FiDownload,
  FiShare2,
  FiBookmark
} from 'react-icons/fi';
import { useQuery } from 'react-query';
import { format } from 'date-fns';
import { Line } from 'react-chartjs-2';
import './IPODetails.css';

// Mock data - replace with API calls
const mockIPOData = {
  id: 1,
  companyName: 'TechCorp Solutions Ltd',
  symbol: 'TECHCORP',
  sector: 'Technology',
  industry: 'Software & IT Services',
  issueSize: 500,
  priceBand: { min: 200, max: 220 },
  openDate: '2024-12-15',
  closeDate: '2024-12-18',
  lotSize: 68,
  status: 'upcoming',
  rating: 4.5,
  description: 'Leading technology solutions provider specializing in cloud computing and AI. The company has a strong track record of innovation and growth in the digital transformation space.',
  highlights: [
    'Strong financial performance with 25% YoY revenue growth',
    'Experienced management team with proven track record',
    'Growing market opportunity in cloud computing',
    'Strong customer base with high retention rates',
    'Innovation leader in AI and machine learning'
  ],
  bookBuilding: true,
  gmp: 25,
  financials: {
    revenue: 250,
    profit: 45,
    assets: 180,
    liabilities: 80,
    equity: 100
  },
  promoters: 65,
  public: 35,
  anchorInvestors: [
    'HDFC Mutual Fund',
    'ICICI Prudential',
    'SBI Mutual Fund',
    'Axis Mutual Fund'
  ],
  leadManagers: [
    'Kotak Mahindra Capital',
    'Morgan Stanley India',
    'Axis Capital'
  ],
  registrar: 'Link Intime India Pvt Ltd',
  timeline: [
    { date: '2024-12-10', event: 'Anchor Investor Bidding' },
    { date: '2024-12-15', event: 'IPO Opens' },
    { date: '2024-12-18', event: 'IPO Closes' },
    { date: '2024-12-19', event: 'Finalization of Basis of Allotment' },
    { date: '2024-12-20', event: 'Initiation of Refunds' },
    { date: '2024-12-23', event: 'Credit of Equity Shares' },
    { date: '2024-12-24', event: 'Listing Date' }
  ]
};

const IPODetails = () => {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState('overview');

  // Mock API call using React Query
  const { data: ipo, isLoading, error } = useQuery(['ipo', id], () => {
    return new Promise((resolve) => {
      setTimeout(() => resolve(mockIPOData), 1000);
    });
  });

  const chartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Revenue (Cr)',
        data: [180, 190, 200, 210, 220, 230, 240, 235, 245, 250, 245, 250],
        borderColor: '#667eea',
        backgroundColor: 'rgba(102, 126, 234, 0.1)',
        fill: true,
        tension: 0.4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: '#f1f5f9',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  if (isLoading) {
    return (
      <div className="loading-container">
        <div className="loading"></div>
        <p>Loading IPO details...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <p>Error loading IPO details. Please try again later.</p>
      </div>
    );
  }

  return (
    <div className="ipo-details">
      <div className="container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="ipo-header"
        >
          <Link to="/upcoming-ipos" className="back-link">
            <FiArrowLeft />
            Back to IPOs
          </Link>
          
          <div className="ipo-title">
            <div>
              <h1>{ipo.companyName}</h1>
              <span className="ipo-symbol">{ipo.symbol}</span>
            </div>
            <div className="ipo-rating">
              <FiStar />
              <span>{ipo.rating}</span>
            </div>
          </div>

          <div className="ipo-status">
            <span className={`status-badge ${ipo.status}`}>
              {ipo.status.charAt(0).toUpperCase() + ipo.status.slice(1)}
            </span>
            {ipo.bookBuilding && (
              <span className="book-building-badge">Book Building</span>
            )}
            {ipo.gmp > 0 && (
              <span className="gmp-badge positive">GMP: +₹{ipo.gmp}</span>
            )}
          </div>
        </motion.div>

        {/* Quick Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="quick-stats"
        >
          <div className="stat-item">
            <span className="label">Issue Size</span>
            <span className="value">₹{ipo.issueSize} Cr</span>
          </div>
          <div className="stat-item">
            <span className="label">Price Band</span>
            <span className="value">₹{ipo.priceBand.min} - ₹{ipo.priceBand.max}</span>
          </div>
          <div className="stat-item">
            <span className="label">Lot Size</span>
            <span className="value">{ipo.lotSize} shares</span>
          </div>
          <div className="stat-item">
            <span className="label">Open Date</span>
            <span className="value">{format(new Date(ipo.openDate), 'MMM dd, yyyy')}</span>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="action-buttons"
        >
          <button className="btn btn-primary">
            <FiEye />
            Apply Now
          </button>
          <button className="btn btn-secondary">
            <FiBookmark />
            Add to Watchlist
          </button>
          <button className="btn btn-secondary">
            <FiDownload />
            Download DRHP
          </button>
          <button className="btn btn-secondary">
            <FiShare2 />
            Share
          </button>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="ipo-tabs"
        >
          <button
            className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </button>
          <button
            className={`tab-btn ${activeTab === 'financials' ? 'active' : ''}`}
            onClick={() => setActiveTab('financials')}
          >
            Financials
          </button>
          <button
            className={`tab-btn ${activeTab === 'timeline' ? 'active' : ''}`}
            onClick={() => setActiveTab('timeline')}
          >
            Timeline
          </button>
          <button
            className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`}
            onClick={() => setActiveTab('details')}
          >
            Details
          </button>
        </motion.div>

        {/* Tab Content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="tab-content"
        >
          {activeTab === 'overview' && (
            <div className="overview-content">
              <div className="content-grid">
                <div className="main-content">
                  <div className="section">
                    <h3>Company Description</h3>
                    <p>{ipo.description}</p>
                  </div>

                  <div className="section">
                    <h3>Key Highlights</h3>
                    <ul className="highlights-list">
                      {ipo.highlights.map((highlight, index) => (
                        <li key={index}>{highlight}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="section">
                    <h3>Revenue Growth</h3>
                    <div className="chart-container">
                      <Line data={chartData} options={chartOptions} />
                    </div>
                  </div>
                </div>

                <div className="sidebar">
                  <div className="info-card">
                    <h3>Company Information</h3>
                    <div className="info-item">
                      <span className="label">Sector</span>
                      <span className="value">{ipo.sector}</span>
                    </div>
                    <div className="info-item">
                      <span className="label">Industry</span>
                      <span className="value">{ipo.industry}</span>
                    </div>
                    <div className="info-item">
                      <span className="label">Promoter Holding</span>
                      <span className="value">{ipo.promoters}%</span>
                    </div>
                    <div className="info-item">
                      <span className="label">Public Holding</span>
                      <span className="value">{ipo.public}%</span>
                    </div>
                  </div>

                  <div className="info-card">
                    <h3>Lead Managers</h3>
                    <ul className="manager-list">
                      {ipo.leadManagers.map((manager, index) => (
                        <li key={index}>{manager}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="info-card">
                    <h3>Registrar</h3>
                    <p>{ipo.registrar}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'financials' && (
            <div className="financials-content">
              <div className="financials-grid">
                <div className="financial-card">
                  <h3>Revenue</h3>
                  <p className="amount">₹{ipo.financials.revenue} Cr</p>
                  <span className="trend positive">
                    <FiTrendingUp />
                    +25% YoY
                  </span>
                </div>
                <div className="financial-card">
                  <h3>Net Profit</h3>
                  <p className="amount">₹{ipo.financials.profit} Cr</p>
                  <span className="trend positive">
                    <FiTrendingUp />
                    +18% YoY
                  </span>
                </div>
                <div className="financial-card">
                  <h3>Total Assets</h3>
                  <p className="amount">₹{ipo.financials.assets} Cr</p>
                  <span className="trend positive">
                    <FiTrendingUp />
                    +12% YoY
                  </span>
                </div>
                <div className="financial-card">
                  <h3>Total Liabilities</h3>
                  <p className="amount">₹{ipo.financials.liabilities} Cr</p>
                  <span className="trend negative">
                    <FiTrendingDown />
                    +8% YoY
                  </span>
                </div>
              </div>

              <div className="financial-details">
                <h3>Financial Ratios</h3>
                <div className="ratios-grid">
                  <div className="ratio-item">
                    <span className="label">P/E Ratio</span>
                    <span className="value">25.5x</span>
                  </div>
                  <div className="ratio-item">
                    <span className="label">ROE</span>
                    <span className="value">18.2%</span>
                  </div>
                  <div className="ratio-item">
                    <span className="label">ROA</span>
                    <span className="value">12.5%</span>
                  </div>
                  <div className="ratio-item">
                    <span className="label">Debt to Equity</span>
                    <span className="value">0.8x</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'timeline' && (
            <div className="timeline-content">
              <div className="timeline">
                {ipo.timeline.map((item, index) => (
                  <div key={index} className="timeline-item">
                    <div className="timeline-date">
                      {format(new Date(item.date), 'MMM dd')}
                    </div>
                    <div className="timeline-content">
                      <h4>{item.event}</h4>
                      <p>{format(new Date(item.date), 'EEEE, MMMM dd, yyyy')}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'details' && (
            <div className="details-content">
              <div className="details-grid">
                <div className="detail-section">
                  <h3>Issue Details</h3>
                  <div className="detail-list">
                    <div className="detail-item">
                      <span className="label">Issue Size</span>
                      <span className="value">₹{ipo.issueSize} Crores</span>
                    </div>
                    <div className="detail-item">
                      <span className="label">Price Band</span>
                      <span className="value">₹{ipo.priceBand.min} - ₹{ipo.priceBand.max}</span>
                    </div>
                    <div className="detail-item">
                      <span className="label">Lot Size</span>
                      <span className="value">{ipo.lotSize} shares</span>
                    </div>
                    <div className="detail-item">
                      <span className="label">Minimum Investment</span>
                      <span className="value">₹{ipo.lotSize * ipo.priceBand.min}</span>
                    </div>
                  </div>
                </div>

                <div className="detail-section">
                  <h3>Important Dates</h3>
                  <div className="detail-list">
                    <div className="detail-item">
                      <span className="label">IPO Open Date</span>
                      <span className="value">{format(new Date(ipo.openDate), 'MMM dd, yyyy')}</span>
                    </div>
                    <div className="detail-item">
                      <span className="label">IPO Close Date</span>
                      <span className="value">{format(new Date(ipo.closeDate), 'MMM dd, yyyy')}</span>
                    </div>
                    <div className="detail-item">
                      <span className="label">Listing Date</span>
                      <span className="value">{format(new Date(ipo.timeline[6].date), 'MMM dd, yyyy')}</span>
                    </div>
                  </div>
                </div>

                <div className="detail-section">
                  <h3>Anchor Investors</h3>
                  <ul className="investor-list">
                    {ipo.anchorInvestors.map((investor, index) => (
                      <li key={index}>{investor}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default IPODetails; 