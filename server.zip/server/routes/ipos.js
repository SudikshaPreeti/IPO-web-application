const express = require('express');
const { Op, sequelize } = require('sequelize');
const { IPO } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/ipos
// @desc    Get all IPOs with filtering and pagination
// @access  Public
router.get('/', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      status,
      sector,
      search,
      sortBy = 'openDate',
      sortOrder = 'ASC'
    } = req.query;

    const offset = (page - 1) * limit;
    const whereClause = {};

    // Filter by status
    if (status) {
      whereClause.status = status;
    }

    // Filter by sector
    if (sector) {
      whereClause.sector = sector;
    }

    // Search functionality
    if (search) {
      whereClause[Op.or] = [
        { companyName: { [Op.iLike]: `%${search}%` } },
        { symbol: { [Op.iLike]: `%${search}%` } },
        { description: { [Op.iLike]: `%${search}%` } }
      ];
    }

    // Validate sort parameters
    const allowedSortFields = ['companyName', 'openDate', 'closeDate', 'priceRange', 'status'];
    const sortField = allowedSortFields.includes(sortBy) ? sortBy : 'openDate';
    const orderDirection = sortOrder.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    const { count, rows: ipos } = await IPO.findAndCountAll({
      where: whereClause,
      order: [[sortField, orderDirection]],
      limit: parseInt(limit),
      offset: parseInt(offset),
      attributes: [
        'id', 'companyName', 'symbol', 'sector', 'status',
        'openDate', 'closeDate', 'priceBandMin', 'priceBandMax', 'issueSize',
        'marketCap', 'description', 'createdAt'
      ]
    });

    const totalPages = Math.ceil(count / limit);

    res.json({
      success: true,
      data: {
        ipos,
        pagination: {
          currentPage: parseInt(page),
          totalPages,
          totalItems: count,
          itemsPerPage: parseInt(limit),
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1
        }
      }
    });

  } catch (error) {
    console.error('Get IPOs error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/ipos/upcoming
// @desc    Get upcoming IPOs
// @access  Public
router.get('/upcoming', async (req, res) => {
  try {
    const { limit = 10 } = req.query;

    const upcomingIPOs = await IPO.findAll({
      where: {
        status: 'upcoming',
        openDate: {
          [Op.gte]: new Date()
        }
      },
      order: [['openDate', 'ASC']],
      limit: parseInt(limit),
      attributes: [
        'id', 'companyName', 'symbol', 'sector', 'status',
        'openDate', 'closeDate', 'priceBandMin', 'priceBandMax', 'issueSize',
        'marketCap', 'description', 'createdAt'
      ]
    });

    res.json({
      success: true,
      data: { ipos: upcomingIPOs }
    });

  } catch (error) {
    console.error('Get upcoming IPOs error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/ipos/:id
// @desc    Get IPO details by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const ipo = await IPO.findByPk(id);
    if (!ipo) {
      return res.status(404).json({
        success: false,
        message: 'IPO not found'
      });
    }

    res.json({
      success: true,
      data: { ipo }
    });

  } catch (error) {
    console.error('Get IPO details error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/ipos
// @desc    Create a new IPO (Admin only)
// @access  Private
router.post('/', authenticateToken, async (req, res) => {
  try {
    // In a real application, check if user is admin
    // For now, we'll allow any authenticated user to create IPOs

    const {
      companyName,
      tickerSymbol,
      sector,
      description,
      openDate,
      closeDate,
      priceRange,
      totalShares,
      marketCap,
      logoUrl,
      prospectusUrl,
      financials
    } = req.body;

    const ipo = await IPO.create({
      companyName,
      tickerSymbol,
      sector,
      description,
      openDate,
      closeDate,
      priceRange,
      totalShares,
      marketCap,
      logoUrl,
      prospectusUrl,
      financials,
      status: 'upcoming'
    });

    res.status(201).json({
      success: true,
      message: 'IPO created successfully',
      data: { ipo }
    });

  } catch (error) {
    console.error('Create IPO error:', error);
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: error.errors.map(err => ({
          field: err.path,
          message: err.message
        }))
      });
    }
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   PUT /api/ipos/:id
// @desc    Update IPO details (Admin only)
// @access  Private
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    const ipo = await IPO.findByPk(id);
    if (!ipo) {
      return res.status(404).json({
        success: false,
        message: 'IPO not found'
      });
    }

    await ipo.update(updateData);

    res.json({
      success: true,
      message: 'IPO updated successfully',
      data: { ipo }
    });

  } catch (error) {
    console.error('Update IPO error:', error);
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: error.errors.map(err => ({
          field: err.path,
          message: err.message
        }))
      });
    }
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   DELETE /api/ipos/:id
// @desc    Delete IPO (Admin only)
// @access  Private
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const ipo = await IPO.findByPk(id);
    if (!ipo) {
      return res.status(404).json({
        success: false,
        message: 'IPO not found'
      });
    }

    await ipo.destroy();

    res.json({
      success: true,
      message: 'IPO deleted successfully'
    });

  } catch (error) {
    console.error('Delete IPO error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/ipos/sectors
// @desc    Get all available sectors
// @access  Public
router.get('/sectors', async (req, res) => {
  try {
    const sectors = await IPO.findAll({
      attributes: [[sequelize.fn('DISTINCT', sequelize.col('sector')), 'sector']],
      where: {
        sector: {
          [Op.not]: null
        }
      },
      raw: true
    });

    const sectorList = sectors.map(item => item.sector).filter(Boolean);

    res.json({
      success: true,
      data: { sectors: sectorList }
    });

  } catch (error) {
    console.error('Get sectors error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

module.exports = router; 