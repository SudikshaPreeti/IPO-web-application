const express = require('express');
const { Op } = require('sequelize');
const { User, IPO } = require('../models');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/dashboard/overview
// @desc    Get dashboard overview data
// @access  Private
router.get('/overview', authenticateToken, async (req, res) => {
  try {
    const user = await User.findByPk(req.user.userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Get upcoming IPOs count
    const upcomingIPOsCount = await IPO.count({
      where: {
        status: 'upcoming',
        openDate: {
          [Op.gte]: new Date()
        }
      }
    });

    // Get active IPOs count
    const activeIPOsCount = await IPO.count({
      where: {
        status: 'active'
      }
    });

    // Get recently listed IPOs (last 30 days)
    const recentlyListedCount = await IPO.count({
      where: {
        status: 'listed',
        listedDate: {
          [Op.gte]: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
        }
      }
    });

    // Mock portfolio data (in a real app, this would come from a Portfolio model)
    const portfolioValue = 0;
    const totalInvested = 0;
    const totalReturn = 0;
    const returnPercentage = 0;

    // Mock watchlist count
    const watchlistCount = 0;

    const overview = {
      stats: {
        upcomingIPOs: upcomingIPOsCount,
        activeIPOs: activeIPOsCount,
        recentlyListed: recentlyListedCount,
        watchlistCount
      },
      portfolio: {
        totalValue: portfolioValue,
        totalInvested,
        totalReturn,
        returnPercentage
      },
      recentActivity: [] // This would come from an Activity model
    };

    res.json({
      success: true,
      data: overview
    });

  } catch (error) {
    console.error('Get dashboard overview error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/dashboard/portfolio
// @desc    Get user portfolio data
// @access  Private
router.get('/portfolio', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    // In a real application, you would have a Portfolio model
    // For now, we'll return mock data
    const mockPortfolio = {
      totalValue: 0,
      totalInvested: 0,
      totalReturn: 0,
      returnPercentage: 0,
      investments: [],
      performance: {
        daily: 0,
        weekly: 0,
        monthly: 0,
        yearly: 0
      }
    };

    res.json({
      success: true,
      data: mockPortfolio
    });

  } catch (error) {
    console.error('Get portfolio error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/dashboard/watchlist
// @desc    Get user watchlist
// @access  Private
router.get('/watchlist', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    // In a real application, you would have a Watchlist model
    // For now, we'll return mock data
    const mockWatchlist = {
      items: [],
      totalCount: 0
    };

    res.json({
      success: true,
      data: mockWatchlist
    });

  } catch (error) {
    console.error('Get watchlist error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   POST /api/dashboard/watchlist
// @desc    Add IPO to watchlist
// @access  Private
router.post('/watchlist', authenticateToken, async (req, res) => {
  try {
    const { ipoId } = req.body;

    if (!ipoId) {
      return res.status(400).json({
        success: false,
        message: 'IPO ID is required'
      });
    }

    // Check if IPO exists
    const ipo = await IPO.findByPk(ipoId);
    if (!ipo) {
      return res.status(404).json({
        success: false,
        message: 'IPO not found'
      });
    }

    // In a real application, you would add to Watchlist model
    // For now, we'll just return success
    res.json({
      success: true,
      message: 'IPO added to watchlist successfully'
    });

  } catch (error) {
    console.error('Add to watchlist error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   DELETE /api/dashboard/watchlist/:ipoId
// @desc    Remove IPO from watchlist
// @access  Private
router.delete('/watchlist/:ipoId', authenticateToken, async (req, res) => {
  try {
    const { ipoId } = req.params;

    // In a real application, you would remove from Watchlist model
    // For now, we'll just return success
    res.json({
      success: true,
      message: 'IPO removed from watchlist successfully'
    });

  } catch (error) {
    console.error('Remove from watchlist error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/dashboard/recent-ipos
// @desc    Get recent IPOs for dashboard
// @access  Private
router.get('/recent-ipos', authenticateToken, async (req, res) => {
  try {
    const { limit = 5 } = req.query;

    const recentIPOs = await IPO.findAll({
      where: {
        status: {
          [Op.in]: ['upcoming', 'active']
        }
      },
      order: [['openDate', 'ASC']],
      limit: parseInt(limit),
      attributes: [
        'id', 'companyName', 'tickerSymbol', 'sector', 'status',
        'openDate', 'closeDate', 'priceRange', 'marketCap'
      ]
    });

    res.json({
      success: true,
      data: { ipos: recentIPOs }
    });

  } catch (error) {
    console.error('Get recent IPOs error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/dashboard/performance
// @desc    Get portfolio performance data
// @access  Private
router.get('/performance', authenticateToken, async (req, res) => {
  try {
    const { period = '1M' } = req.query;

    // In a real application, you would calculate actual performance
    // For now, we'll return mock data
    const mockPerformance = {
      period,
      data: [],
      summary: {
        totalReturn: 0,
        returnPercentage: 0,
        bestPerformer: null,
        worstPerformer: null
      }
    };

    res.json({
      success: true,
      data: mockPerformance
    });

  } catch (error) {
    console.error('Get performance error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/dashboard/alerts
// @desc    Get user alerts and notifications
// @access  Private
router.get('/alerts', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    // In a real application, you would have an Alerts model
    // For now, we'll return mock data
    const mockAlerts = {
      alerts: [],
      unreadCount: 0,
      totalCount: 0
    };

    res.json({
      success: true,
      data: mockAlerts
    });

  } catch (error) {
    console.error('Get alerts error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   PUT /api/dashboard/alerts/:alertId/read
// @desc    Mark alert as read
// @access  Private
router.put('/alerts/:alertId/read', authenticateToken, async (req, res) => {
  try {
    const { alertId } = req.params;

    // In a real application, you would update the alert status
    // For now, we'll just return success
    res.json({
      success: true,
      message: 'Alert marked as read'
    });

  } catch (error) {
    console.error('Mark alert as read error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// @route   GET /api/dashboard/sectors
// @desc    Get sector distribution for portfolio
// @access  Private
router.get('/sectors', authenticateToken, async (req, res) => {
  try {
    // In a real application, you would calculate sector distribution
    // For now, we'll return mock data
    const mockSectors = {
      sectors: [],
      totalValue: 0
    };

    res.json({
      success: true,
      data: mockSectors
    });

  } catch (error) {
    console.error('Get sectors error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

module.exports = router; 