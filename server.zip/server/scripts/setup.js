const { sequelize } = require('../config/database');
const { User, IPO } = require('../models');
const bcrypt = require('bcryptjs');

async function setupDatabase() {
  try {
    console.log('🔄 Setting up database...');

    // Sync database models
    await sequelize.sync({ force: true });
    console.log('✅ Database models synchronized');

    // Create admin user
    const adminPassword = await bcrypt.hash('Admin123!', 12);
    const adminUser = await User.create({
      email: 'admin@bluestockfintech.com',
      password: adminPassword,
      firstName: 'Admin',
      lastName: 'User',
      phone: '+1234567890',
      isActive: true,
      role: 'admin',
      isEmailVerified: true
    });
    console.log('✅ Admin user created');

    // Create sample user
    const userPassword = await bcrypt.hash('User123!', 12);
    const sampleUser = await User.create({
      email: 'user@example.com',
      password: userPassword,
      firstName: 'John',
      lastName: 'Doe',
      phone: '+1987654321',
      isActive: true,
      role: 'user',
      isEmailVerified: true
    });
    console.log('✅ Sample user created');

    // Create sample IPOs
    const sampleIPOs = [
      {
        companyName: 'TechCorp Solutions',
        symbol: 'TCS',
        sector: 'Technology',
        description: 'Leading technology solutions provider specializing in cloud computing and AI services.',
        openDate: new Date('2024-02-15'),
        closeDate: new Date('2024-02-20'),
        priceBandMin: 25,
        priceBandMax: 30,
        issueSize: 275000000,
        lotSize: 100,
        marketCap: 275000000,
        status: 'upcoming',
        financials: {
          revenue: 500000000,
          profit: 75000000,
          assets: 800000000,
          liabilities: 300000000
        }
      },
      {
        companyName: 'GreenEnergy Inc',
        symbol: 'GEI',
        sector: 'Energy',
        description: 'Renewable energy company focused on solar and wind power solutions.',
        openDate: new Date('2024-02-25'),
        closeDate: new Date('2024-03-02'),
        priceBandMin: 18,
        priceBandMax: 22,
        issueSize: 300000000,
        lotSize: 150,
        marketCap: 300000000,
        status: 'upcoming',
        financials: {
          revenue: 300000000,
          profit: 45000000,
          assets: 600000000,
          liabilities: 200000000
        }
      },
      {
        companyName: 'HealthTech Innovations',
        symbol: 'HTI',
        sector: 'Healthcare',
        description: 'Healthcare technology company developing innovative medical devices and software.',
        openDate: new Date('2024-01-10'),
        closeDate: new Date('2024-01-15'),
        priceBandMin: 35,
        priceBandMax: 40,
        issueSize: 300000000,
        lotSize: 80,
        marketCap: 300000000,
        status: 'listed',
        listingDate: new Date('2024-01-16'),
        listingPrice: 38.50,
        currentPrice: 42.75,
        financials: {
          revenue: 200000000,
          profit: 30000000,
          assets: 400000000,
          liabilities: 150000000
        }
      },
      {
        companyName: 'FinServ Solutions',
        symbol: 'FSS',
        sector: 'Financial Services',
        description: 'Financial services technology platform for digital banking and payments.',
        openDate: new Date('2024-03-10'),
        closeDate: new Date('2024-03-15'),
        priceBandMin: 28,
        priceBandMax: 32,
        issueSize: 360000000,
        lotSize: 120,
        marketCap: 360000000,
        status: 'upcoming',
        financials: {
          revenue: 400000000,
          profit: 60000000,
          assets: 700000000,
          liabilities: 250000000
        }
      },
      {
        companyName: 'EcoRetail Group',
        symbol: 'ERG',
        sector: 'Retail',
        description: 'Sustainable retail chain focusing on eco-friendly products and practices.',
        openDate: new Date('2024-01-20'),
        closeDate: new Date('2024-01-25'),
        priceBandMin: 15,
        priceBandMax: 18,
        issueSize: 330000000,
        lotSize: 200,
        marketCap: 330000000,
        status: 'listed',
        listingDate: new Date('2024-01-26'),
        listingPrice: 16.75,
        currentPrice: 19.25,
        financials: {
          revenue: 600000000,
          profit: 90000000,
          assets: 1000000000,
          liabilities: 400000000
        }
      }
    ];

    for (const ipoData of sampleIPOs) {
      await IPO.create(ipoData);
    }
    console.log('✅ Sample IPOs created');

    console.log('\n🎉 Database setup completed successfully!');
    console.log('\n📋 Sample Data:');
    console.log('- Admin User: admin@bluestockfintech.com / Admin123!');
    console.log('- Sample User: user@example.com / User123!');
    console.log('- 5 Sample IPOs created');
    console.log('\n🚀 You can now start the application with: npm run dev');

  } catch (error) {
    console.error('❌ Database setup failed:', error);
    process.exit(1);
  } finally {
    await sequelize.close();
  }
}

// Run setup if this file is executed directly
if (require.main === module) {
  setupDatabase();
}

module.exports = setupDatabase; 