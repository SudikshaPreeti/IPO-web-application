const { body, validationResult } = require('express-validator');

/**
 * Handle validation errors
 */
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors: errors.array().map(error => ({
        field: error.path,
        message: error.msg,
        value: error.value
      }))
    });
  }
  next();
};

/**
 * Registration validation rules
 */
const validateRegistration = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
    .withMessage('Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'),
  
  body('firstName')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('First name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('First name can only contain letters and spaces'),
  
  body('lastName')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Last name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('Last name can only contain letters and spaces'),
  
  body('phone')
    .optional()
    .isMobilePhone()
    .withMessage('Please provide a valid phone number'),
  
  handleValidationErrors
];

/**
 * Login validation rules
 */
const validateLogin = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  
  handleValidationErrors
];

/**
 * Profile update validation rules
 */
const validateProfileUpdate = [
  body('firstName')
    .optional()
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('First name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('First name can only contain letters and spaces'),
  
  body('lastName')
    .optional()
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Last name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('Last name can only contain letters and spaces'),
  
  body('phone')
    .optional()
    .isMobilePhone()
    .withMessage('Please provide a valid phone number'),
  
  body('dateOfBirth')
    .optional()
    .isISO8601()
    .withMessage('Please provide a valid date of birth'),
  
  handleValidationErrors
];

/**
 * IPO creation validation rules
 */
const validateIPOCreation = [
  body('companyName')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Company name must be between 2 and 100 characters'),
  
  body('tickerSymbol')
    .trim()
    .isLength({ min: 1, max: 10 })
    .withMessage('Ticker symbol must be between 1 and 10 characters')
    .matches(/^[A-Z]+$/)
    .withMessage('Ticker symbol must contain only uppercase letters'),
  
  body('sector')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Sector must be between 2 and 50 characters'),
  
  body('description')
    .trim()
    .isLength({ min: 10, max: 1000 })
    .withMessage('Description must be between 10 and 1000 characters'),
  
  body('openDate')
    .isISO8601()
    .withMessage('Please provide a valid open date'),
  
  body('closeDate')
    .isISO8601()
    .withMessage('Please provide a valid close date')
    .custom((value, { req }) => {
      if (new Date(value) <= new Date(req.body.openDate)) {
        throw new Error('Close date must be after open date');
      }
      return true;
    }),
  
  body('priceRange')
    .isObject()
    .withMessage('Price range must be an object')
    .custom((value) => {
      if (!value.min || !value.max) {
        throw new Error('Price range must have min and max values');
      }
      if (value.min >= value.max) {
        throw new Error('Min price must be less than max price');
      }
      if (value.min < 0 || value.max < 0) {
        throw new Error('Prices must be positive');
      }
      return true;
    }),
  
  body('totalShares')
    .isInt({ min: 1 })
    .withMessage('Total shares must be a positive integer'),
  
  body('marketCap')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Market cap must be a positive number'),
  
  body('logoUrl')
    .optional()
    .isURL()
    .withMessage('Please provide a valid logo URL'),
  
  body('prospectusUrl')
    .optional()
    .isURL()
    .withMessage('Please provide a valid prospectus URL'),
  
  handleValidationErrors
];

/**
 * IPO update validation rules
 */
const validateIPOUpdate = [
  body('companyName')
    .optional()
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Company name must be between 2 and 100 characters'),
  
  body('tickerSymbol')
    .optional()
    .trim()
    .isLength({ min: 1, max: 10 })
    .withMessage('Ticker symbol must be between 1 and 10 characters')
    .matches(/^[A-Z]+$/)
    .withMessage('Ticker symbol must contain only uppercase letters'),
  
  body('sector')
    .optional()
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Sector must be between 2 and 50 characters'),
  
  body('description')
    .optional()
    .trim()
    .isLength({ min: 10, max: 1000 })
    .withMessage('Description must be between 10 and 1000 characters'),
  
  body('openDate')
    .optional()
    .isISO8601()
    .withMessage('Please provide a valid open date'),
  
  body('closeDate')
    .optional()
    .isISO8601()
    .withMessage('Please provide a valid close date'),
  
  body('priceRange')
    .optional()
    .isObject()
    .withMessage('Price range must be an object')
    .custom((value) => {
      if (!value.min || !value.max) {
        throw new Error('Price range must have min and max values');
      }
      if (value.min >= value.max) {
        throw new Error('Min price must be less than max price');
      }
      if (value.min < 0 || value.max < 0) {
        throw new Error('Prices must be positive');
      }
      return true;
    }),
  
  body('totalShares')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Total shares must be a positive integer'),
  
  body('marketCap')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Market cap must be a positive number'),
  
  body('logoUrl')
    .optional()
    .isURL()
    .withMessage('Please provide a valid logo URL'),
  
  body('prospectusUrl')
    .optional()
    .isURL()
    .withMessage('Please provide a valid prospectus URL'),
  
  handleValidationErrors
];

/**
 * Password change validation rules
 */
const validatePasswordChange = [
  body('currentPassword')
    .notEmpty()
    .withMessage('Current password is required'),
  
  body('newPassword')
    .isLength({ min: 8 })
    .withMessage('New password must be at least 8 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
    .withMessage('New password must contain at least one uppercase letter, one lowercase letter, one number, and one special character')
    .custom((value, { req }) => {
      if (value === req.body.currentPassword) {
        throw new Error('New password must be different from current password');
      }
      return true;
    }),
  
  handleValidationErrors
];

module.exports = {
  handleValidationErrors,
  validateRegistration,
  validateLogin,
  validateProfileUpdate,
  validateIPOCreation,
  validateIPOUpdate,
  validatePasswordChange
}; 