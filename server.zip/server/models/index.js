const { Sequelize } = require('sequelize');
const { sequelize } = require('../config/database');

// Import models (they are already defined with sequelize.define)
const User = require('./User');
const IPO = require('./IPO');

// Models are already initialized, just export them
const models = {
  User,
  IPO
};

// Define associations
Object.keys(models).forEach(modelName => {
  if (models[modelName].associate) {
    models[modelName].associate(models);
  }
});

// Export models and sequelize instance
module.exports = {
  ...models,
  sequelize,
  Sequelize
}; 