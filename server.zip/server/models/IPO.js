const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const IPO = sequelize.define('IPO', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  companyName: {
    type: DataTypes.STRING(200),
    allowNull: false,
    validate: {
      notEmpty: true
    }
  },
  symbol: {
    type: DataTypes.STRING(20),
    allowNull: false,
    unique: true,
    validate: {
      notEmpty: true,
      len: [1, 20]
    }
  },
  sector: {
    type: DataTypes.STRING(100),
    allowNull: false,
    validate: {
      notEmpty: true
    }
  },
  industry: {
    type: DataTypes.STRING(100),
    allowNull: true
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  issueSize: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: false,
    validate: {
      min: 0
    }
  },
  priceBandMin: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    validate: {
      min: 0
    }
  },
  priceBandMax: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    validate: {
      min: 0
    }
  },
  lotSize: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1
    }
  },
  openDate: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  closeDate: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  listingDate: {
    type: DataTypes.DATEONLY,
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('upcoming', 'open', 'closed', 'listed', 'withdrawn'),
    defaultValue: 'upcoming',
    allowNull: false
  },
  bookBuilding: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  gmp: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
    comment: 'Grey Market Premium'
  },
  rating: {
    type: DataTypes.DECIMAL(3, 1),
    allowNull: true,
    validate: {
      min: 0,
      max: 5
    }
  },
  promoters: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: true,
    comment: 'Promoter holding percentage'
  },
  public: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: true,
    comment: 'Public holding percentage'
  },
  financials: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'Financial data like revenue, profit, etc.'
  },
  highlights: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'Key highlights of the IPO'
  },
  anchorInvestors: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'List of anchor investors'
  },
  leadManagers: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'List of lead managers'
  },
  registrar: {
    type: DataTypes.STRING(200),
    allowNull: true
  },
  timeline: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'IPO timeline events'
  },
  documents: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'DRHP, prospectus, etc.'
  },
  subscriptionData: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'Subscription data for different categories'
  },
  allotmentData: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'Allotment data and basis'
  },
  listingPrice: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true
  },
  currentPrice: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true
  },
  marketCap: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: true
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  isFeatured: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  tags: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'Tags for categorization'
  },
  metadata: {
    type: DataTypes.JSONB,
    allowNull: true,
    comment: 'Additional metadata'
  }
}, {
  tableName: 'ipos',
  indexes: [
    {
      fields: ['status']
    },
    {
      fields: ['sector']
    },
    {
      fields: ['open_date']
    },
    {
      fields: ['symbol']
    },
    {
      fields: ['is_active']
    }
  ]
});

// Instance methods
IPO.prototype.getPriceBand = function() {
  return {
    min: this.priceBandMin,
    max: this.priceBandMax
  };
};

IPO.prototype.getMinimumInvestment = function() {
  return this.lotSize * this.priceBandMin;
};

IPO.prototype.getMaximumInvestment = function() {
  return this.lotSize * this.priceBandMax;
};

IPO.prototype.isOpen = function() {
  const today = new Date();
  const openDate = new Date(this.openDate);
  const closeDate = new Date(this.closeDate);
  return today >= openDate && today <= closeDate;
};

IPO.prototype.isUpcoming = function() {
  const today = new Date();
  const openDate = new Date(this.openDate);
  return today < openDate;
};

IPO.prototype.isClosed = function() {
  const today = new Date();
  const closeDate = new Date(this.closeDate);
  return today > closeDate;
};

// Class methods
IPO.findUpcoming = function() {
  return this.findAll({
    where: {
      status: 'upcoming',
      isActive: true
    },
    order: [['openDate', 'ASC']]
  });
};

IPO.findOpen = function() {
  return this.findAll({
    where: {
      status: 'open',
      isActive: true
    },
    order: [['closeDate', 'ASC']]
  });
};

IPO.findBySector = function(sector) {
  return this.findAll({
    where: {
      sector: sector,
      isActive: true
    },
    order: [['openDate', 'DESC']]
  });
};

IPO.findFeatured = function() {
  return this.findAll({
    where: {
      isFeatured: true,
      isActive: true
    },
    order: [['openDate', 'ASC']]
  });
};

module.exports = IPO; 